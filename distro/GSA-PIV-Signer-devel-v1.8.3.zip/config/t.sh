for F in 37 39 46 47 49 50 51 52; do
	for G in chuid finger facial printed; do
		H=$(grep ^fascn= c$F*$G*.properties)
		echo $F: $H
	done
	echo
done

for F in 37 39 46 47 49 50 51 52; do
	for G in chuid finger facial printed; do
		H=$(grep ^uuid= c$F*$G*.properties)
		echo $F: $H
	done
	echo
done

