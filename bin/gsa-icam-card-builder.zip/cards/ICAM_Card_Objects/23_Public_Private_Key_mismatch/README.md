## Key Mismatch
This particular card is designed to have a public key that matches the Golden PIV Card 1.

The steps for creating this card are:

1. Write the objects in this directory to the card using key injection (i.e., you must have administrative access to the cards).
2. Generate new PIV Authentication and asymmetric Card Authentication keys, but ignore the public key