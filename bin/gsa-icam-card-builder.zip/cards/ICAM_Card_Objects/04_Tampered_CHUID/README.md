## Tampered CHUID ##

After signing the CHUID object, run the script, "alterchuid.sh" which 
will change a byte in the CHUID so that it doesn't match the CHUID's
signature.

Alternatively, use a hex editor to change the 3rd and 4th bytes in the '8 - CHUID Object' file.
